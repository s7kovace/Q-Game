﻿/* $ PlayForm.cs
 * Assignment 3
 * Revision History
 * 
 * Stefan Kovacevic, 2020.12.06: Created, Revised, Tested
 * Student ID: 7202039
 
 */
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

/// <summary>
/// User Loads game design (Qgame file) and can play the game
/// </summary>
namespace Q_Game
{
    /// <summary>
    /// Play form of the game
    /// </summary>
    public partial class PlayForm : Form
    {
        private const int INIT_TOP = 30;
        private const int INIT_LEFT = 50;
        private const int WIDTH = 50;
        private const int HEIGHT = 50;
        private bool isBox = false;
        private Image redDoor = Q_Game.Properties.Resources.redDoor;
        private Image greenDoor = Q_Game.Properties.Resources.greenDoor;
        private Image greenBox = Q_Game.Properties.Resources.greenBox;
        private Image redBox = Q_Game.Properties.Resources.redBox;
        private Image wall = Q_Game.Properties.Resources.brickWall;
        private Image noImage = Q_Game.Properties.Resources.silverSquare;
        int boxCount = 0, movesMade = 0, globalRows, globalCol;
        Tile[,] tileArray;
        Tile activeTile;
        Tile selectedTile;

        /// <summary>
        /// Main constructor of the PlayForm
        /// </summary>
        public PlayForm()
        {
            InitializeComponent();

        }

        private void closeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }



        private void loadGameToolStripMenuItem_Click(object sender, EventArgs e)
        {

            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Filter = "QGAME File(*.qgame)|*.qgame";

            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {

                foreach (Tile t in pnlPlayGame.Controls.OfType<Tile>().ToArray())
                {
                    t.Dispose();
                    pnlPlayGame.Controls.Remove(t);
                }

                string filePath = openFileDialog.FileName;

                using (StreamReader sr = new StreamReader(filePath))
                {
                    string[] informationFromFile = File.ReadAllLines(filePath);
                    int rows = int.Parse(informationFromFile[0]);
                    int columns = int.Parse(informationFromFile[1]);
                    tileArray = new Tile[rows, columns];
                    int arrayRow = 0, arrayColumn = 0;
                    int xPositionOfTile = INIT_LEFT, yPositionOfTile = INIT_TOP;
                    EnableButtons();
                    boxCount = 0;
                    movesMade = 0;
                    globalRows = rows;
                    globalCol = columns;

                    for (int i = 2; i < informationFromFile.Length - 2; i = i + 3)
                    {


                        int tileRow = int.Parse(informationFromFile[i]);
                        int tileCol = int.Parse(informationFromFile[i + 1]);
                        int tileType = int.Parse(informationFromFile[i + 2]);

                        Tile t = new Tile(tileRow, tileCol, tileType);
                        t.Height = HEIGHT;
                        t.Width = WIDTH;
                        t.SizeMode = PictureBoxSizeMode.Zoom;
                        t.Click += new EventHandler(DynamicPictureBox_Click);


                        /// Red Door = 1
                        /// Red Box = 2
                        /// Green Box = 3
                        /// Green Door = 4
                        /// Wall = 5
                        switch (tileType)
                        {
                            case 1:
                                t.Image = redDoor;
                                break;
                            case 2:
                                t.Image = redBox;
                                break;
                            case 3:
                                t.Image = greenBox;
                                break;
                            case 4:
                                t.Image = greenDoor;
                                break;
                            case 5:
                                t.Image = wall;
                                break;
                            default:
                                t.Image = null;
                                break;
                        }

                        if (arrayColumn == columns)
                        {
                            arrayRow++;
                            arrayColumn = 0;
                        }

                        if (t.Image != null)
                        {
                            tileArray[arrayRow, arrayColumn] = t;
                        }

                        arrayColumn++;

                    }

                    for (int i = 0; i < tileArray.GetLength(0); i++)
                    {
                        for (int j = 0; j < tileArray.GetLength(1); j++)
                        {

                            activeTile = tileArray[i, j];

                            if (activeTile != null)
                            {
                                activeTile.Left = xPositionOfTile;
                                activeTile.Top = yPositionOfTile;
                                pnlPlayGame.Controls.Add(activeTile);
                                xPositionOfTile += WIDTH;

                            }
                            else
                            {
                                xPositionOfTile += WIDTH;

                            }



                        }
                        yPositionOfTile += HEIGHT;
                        xPositionOfTile = INIT_LEFT;
                    }

                    foreach (Tile t in tileArray)
                    {
                        if (t != null)
                        {
                            if (t.Image == redBox || t.Image == greenBox)
                            {
                                boxCount++;
                            }
                        }
                    }

                    txtBoxCounter.Text = boxCount.ToString();
                    txtMoveCounter.Text = movesMade.ToString();


                }

            }
        }

        private void PlayForm_Load(object sender, EventArgs e)
        {
            DisableButtons();
        }

        private void DynamicPictureBox_Click(object sender, EventArgs e)
        {

            Tile tile = (Tile)sender;

            foreach (PictureBox pb in tileArray)
            {
                if (pb != null)
                {
                    pb.BackColor = Color.Transparent;
                }

            }
            selectedTile = null;

            if (tile.Image == greenBox || tile.Image == redBox)
            {

                tile.Focus();
                tile.Select();
                tile.BackColor = Color.Blue;
                isBox = true;
                selectedTile = tile;

            }

            else
            {
                isBox = false;
            }
        }


        #region MovementOfTiles
        private void btnUp_Click(object sender, EventArgs e)
        {
            if (isBox == true)
            {
                IncrementMoves();
                bool continueMove = true;
                int rowCounter = selectedTile.Row - 1;
                Tile GetTileValue;

                while (continueMove == true)
                {
                    GetTileValue = GetTile(rowCounter, selectedTile.Col);

                    if (GetTileValue == null)
                    {
                        continueMove = true;
                        selectedTile.Top -= HEIGHT;
                        rowCounter--;

                    }
                    else if (GetTileValue != null)
                    {
                        if (GetTileValue.Image == redDoor || GetTileValue.Image == greenDoor)
                        {
                            if (CheckIfDoorAndBoxMatch(GetTileValue) == true)
                            {

                                CheckForWin();
                                break;

                            }

                        }
                        if (GetTileValue.Image == redBox || GetTileValue.Image == wall || GetTileValue.Image == greenBox || GetTileValue.Image == redDoor || GetTileValue.Image == greenDoor)
                        {
                            continueMove = false;
                            selectedTile.Row = rowCounter + 1;
                        }


                        else
                        {
                            selectedTile.Top -= HEIGHT;
                            rowCounter--;
                            continueMove = true;

                        }
                    }

                }
            }
            else
            {
                MessageBox.Show("Click a box to select!", "QGame", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }


        }

        private void btnDown_Click(object sender, EventArgs e)
        {
            if (isBox == true)
            {
                IncrementMoves();
                bool continueMove = true;
                int rowCounter = selectedTile.Row + 1;
                Tile GetTileValue;

                while (continueMove == true)
                {
                    GetTileValue = GetTile(rowCounter, selectedTile.Col);

                    if (GetTileValue == null)
                    {
                        continueMove = true;
                        selectedTile.Top += HEIGHT;
                        rowCounter++;

                    }
                    else if (GetTileValue != null)
                    {
                        if (GetTileValue.Image == redDoor || GetTileValue.Image == greenDoor)
                        {
                            if (CheckIfDoorAndBoxMatch(GetTileValue) == true)
                            {
                                CheckForWin();
                                break;
                            }
                            else
                            {

                            }


                        }
                        if (GetTileValue.Image == redBox || GetTileValue.Image == wall || GetTileValue.Image == greenBox || GetTileValue.Image == redDoor || GetTileValue.Image == greenDoor)
                        {
                            continueMove = false;
                            selectedTile.Row = rowCounter - 1;
                        }
                        else
                        {
                            selectedTile.Top += HEIGHT;
                            rowCounter++;
                            continueMove = true;

                        }
                    }

                }
            }
            else
            {
                MessageBox.Show("Click a box to select!", "QGame", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void btnLeft_Click(object sender, EventArgs e)
        {
            if (isBox == true)
            {
                IncrementMoves();
                bool continueMove = true;
                int columnCounter = selectedTile.Col - 1;
                Tile GetTileValue;

                while (continueMove == true)
                {
                    GetTileValue = GetTile(selectedTile.Row, columnCounter);

                    if (GetTileValue == null)
                    {
                        continueMove = true;
                        selectedTile.Left -= WIDTH;
                        columnCounter--;

                    }
                    else if (GetTileValue != null)
                    {
                        if (GetTileValue.Image == redDoor || GetTileValue.Image == greenDoor)
                        {
                            if (CheckIfDoorAndBoxMatch(GetTileValue) == true)
                            {
                                CheckForWin();
                                break;

                            }

                        }
                        if (GetTileValue.Image == redBox || GetTileValue.Image == wall || GetTileValue.Image == greenBox || GetTileValue.Image == redDoor || GetTileValue.Image == greenDoor)
                        {
                            continueMove = false;
                            selectedTile.Col = columnCounter + 1;
                        }
                        else
                        {
                            selectedTile.Left -= WIDTH;
                            columnCounter--;
                            continueMove = true;

                        }
                    }

                }
            }
            else
            {
                MessageBox.Show("Click a box to select!", "QGame", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }

        }

        private void btnRight_Click(object sender, EventArgs e)
        {
            if (isBox == true)
            {
                IncrementMoves();
                bool continueMove = true;
                int columnCounter = selectedTile.Col + 1;
                Tile GetTileValue;

                while (continueMove == true)
                {
                    GetTileValue = GetTile(selectedTile.Row, columnCounter);

                    if (GetTileValue == null)
                    {
                        continueMove = true;
                        selectedTile.Left += WIDTH;
                        columnCounter++;

                    }
                    else if (GetTileValue != null)
                    {
                        if (GetTileValue.Image == redDoor || GetTileValue.Image == greenDoor)
                        {
                            if (CheckIfDoorAndBoxMatch(GetTileValue) == true)
                            {
                                CheckForWin();
                                break;

                            }

                        }
                        if (GetTileValue.Image == redBox || GetTileValue.Image == wall || GetTileValue.Image == greenBox || GetTileValue.Image == redDoor || GetTileValue.Image == greenDoor)
                        {
                            continueMove = false;
                            selectedTile.Col = columnCounter - 1;
                        }
                        else
                        {
                            selectedTile.Left += WIDTH;
                            columnCounter++;
                            continueMove = true;

                        }
                    }

                }
            }
            else
            {
                MessageBox.Show("Click a box to select!", "QGame", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }
        #endregion

        #region Methods
        /// <summary>
        /// Returns a selected tile position at given row and column parameters
        /// </summary>
        /// <param name="row">Row of the tile</param>
        /// <param name="col">Column of the tile</param>
        /// <returns></returns>
        public Tile GetTile(int row, int col)
        {
            //if (row> globalRows || col > globalCol || row < -1 || col < -1)
            //{
            //    throw new Exception("Tile cannot leave the grild");

            //}

            foreach (Tile t in tileArray)
            {
                if (t != null)
                {
                    if (t.Row == row && t.Col == col)
                    {
                        return t;
                    }
                }

            }
            return null;




        }

        /// <summary>
        /// If a box intersects with a door this method checks if they are matching colours. If so it removes the tile from the array and 
        /// it removes the tile from the playfield(panel), otherwise returns false
        /// </summary>
        /// <param name="t"></param>
        /// <returns></returns>
        public bool CheckIfDoorAndBoxMatch(Tile t)
        {
            if ((selectedTile.Image == redBox && t.Image == redDoor) || (selectedTile.Image == greenBox && t.Image == greenDoor))
            {
                for (int i = 0; i < tileArray.GetLength(0); i++)
                {
                    for (int j = 0; j < tileArray.GetLength(1); j++)
                    {
                        if (tileArray[i, j] != null)
                        {
                            if (tileArray[i, j].Row == selectedTile.Row && tileArray[i, j].Col == selectedTile.Col)
                            {
                                tileArray[i, j] = null;
                                pnlPlayGame.Controls.Remove(selectedTile);
                                boxCount--;
                                txtBoxCounter.Text = boxCount.ToString();
                                return true;
                            }
                        }


                    }

                }
                return false;

            }
            else

                return false;

        }

        /// <summary>
        /// Increments the movesmade number so that user can keep track of moves made
        /// </summary>
        public void IncrementMoves()
        {
            movesMade++;
            txtMoveCounter.Text = movesMade.ToString();
        }

        public void EnableButtons()
        {
            btnUp.Enabled = true;
            btnLeft.Enabled = true;
            btnRight.Enabled = true;
            btnDown.Enabled = true;
        }


        public void DisableButtons()
        {
            btnUp.Enabled = false;
            btnLeft.Enabled = false;
            btnRight.Enabled = false;
            btnDown.Enabled = false;

        }

        /// <summary>
        /// This method goes through the tiles in the tile array and checks if there is and tile that has a box. If there is a tile that has a box the game continues,
        /// otherwise the game ends
        /// </summary>
        public void CheckForWin()
        {
            int remainingBoxesLeft = 0;

            foreach (Tile tile in tileArray)
            {
                if (tile != null && (tile.TileType == 2 || tile.TileType == 3))
                {
                    remainingBoxesLeft++;
                }
            }
            if (remainingBoxesLeft == 0)
            {
                DialogResult result = MessageBox.Show("Congratulations \nGame End", "QGame", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                if (result == DialogResult.OK || result == DialogResult.Cancel)
                {
                    foreach (Tile t in pnlPlayGame.Controls.OfType<Tile>().ToArray())
                    {
                        t.Dispose();
                        pnlPlayGame.Controls.Remove(t);
                    }

                    movesMade = 0;
                    boxCount = 0;
                    txtMoveCounter.Text = movesMade.ToString();
                    txtBoxCounter.Text = boxCount.ToString();
                    globalRows = 0;
                    globalCol = 0;
                    DisableButtons();
                }
            }

        }
        #endregion
    }
}
