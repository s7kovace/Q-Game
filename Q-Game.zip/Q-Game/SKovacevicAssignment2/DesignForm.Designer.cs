﻿namespace Q_Game
{
    partial class DesignForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip = new System.Windows.Forms.MenuStrip();
            this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.saveToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pnlRowsAndColumns = new System.Windows.Forms.Panel();
            this.lblColumns = new System.Windows.Forms.Label();
            this.lblRows = new System.Windows.Forms.Label();
            this.btnGenerate = new System.Windows.Forms.Button();
            this.txtColumns = new System.Windows.Forms.TextBox();
            this.txtRows = new System.Windows.Forms.TextBox();
            this.pnlToolBox = new System.Windows.Forms.Panel();
            this.rdbNone = new System.Windows.Forms.RadioButton();
            this.rdbGreenBox = new System.Windows.Forms.RadioButton();
            this.rdbRedBox = new System.Windows.Forms.RadioButton();
            this.rdbGreenDoor = new System.Windows.Forms.RadioButton();
            this.rdbWall = new System.Windows.Forms.RadioButton();
            this.rdbRedDoor = new System.Windows.Forms.RadioButton();
            this.lblToolbox = new System.Windows.Forms.Label();
            this.menuStrip.SuspendLayout();
            this.pnlRowsAndColumns.SuspendLayout();
            this.pnlToolBox.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip
            // 
            this.menuStrip.GripMargin = new System.Windows.Forms.Padding(2, 2, 0, 2);
            this.menuStrip.ImageScalingSize = new System.Drawing.Size(24, 24);
            this.menuStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem});
            this.menuStrip.Location = new System.Drawing.Point(0, 0);
            this.menuStrip.Name = "menuStrip";
            this.menuStrip.Padding = new System.Windows.Forms.Padding(8, 2, 0, 2);
            this.menuStrip.Size = new System.Drawing.Size(1633, 48);
            this.menuStrip.TabIndex = 0;
            this.menuStrip.Text = "menuStrip";
            // 
            // fileToolStripMenuItem
            // 
            this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.saveToolStripMenuItem,
            this.exitToolStripMenuItem});
            this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            this.fileToolStripMenuItem.Size = new System.Drawing.Size(72, 44);
            this.fileToolStripMenuItem.Text = "File";
            // 
            // saveToolStripMenuItem
            // 
            this.saveToolStripMenuItem.Name = "saveToolStripMenuItem";
            this.saveToolStripMenuItem.Size = new System.Drawing.Size(207, 44);
            this.saveToolStripMenuItem.Text = "Save";
            this.saveToolStripMenuItem.Click += new System.EventHandler(this.saveToolStripMenuItem_Click);
            // 
            // exitToolStripMenuItem
            // 
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            this.exitToolStripMenuItem.Size = new System.Drawing.Size(207, 44);
            this.exitToolStripMenuItem.Text = "Close";
            this.exitToolStripMenuItem.Click += new System.EventHandler(this.exitToolStripMenuItem_Click);
            // 
            // pnlRowsAndColumns
            // 
            this.pnlRowsAndColumns.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlRowsAndColumns.Controls.Add(this.lblColumns);
            this.pnlRowsAndColumns.Controls.Add(this.lblRows);
            this.pnlRowsAndColumns.Controls.Add(this.btnGenerate);
            this.pnlRowsAndColumns.Controls.Add(this.txtColumns);
            this.pnlRowsAndColumns.Controls.Add(this.txtRows);
            this.pnlRowsAndColumns.Location = new System.Drawing.Point(0, 45);
            this.pnlRowsAndColumns.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.pnlRowsAndColumns.Name = "pnlRowsAndColumns";
            this.pnlRowsAndColumns.Size = new System.Drawing.Size(858, 96);
            this.pnlRowsAndColumns.TabIndex = 1;
            // 
            // lblColumns
            // 
            this.lblColumns.AutoSize = true;
            this.lblColumns.Location = new System.Drawing.Point(292, 32);
            this.lblColumns.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblColumns.Name = "lblColumns";
            this.lblColumns.Size = new System.Drawing.Size(102, 25);
            this.lblColumns.TabIndex = 4;
            this.lblColumns.Text = "Columns:";
            // 
            // lblRows
            // 
            this.lblRows.AutoSize = true;
            this.lblRows.Location = new System.Drawing.Point(17, 32);
            this.lblRows.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblRows.Name = "lblRows";
            this.lblRows.Size = new System.Drawing.Size(71, 25);
            this.lblRows.TabIndex = 3;
            this.lblRows.Text = "Rows:";
            // 
            // btnGenerate
            // 
            this.btnGenerate.Location = new System.Drawing.Point(641, 16);
            this.btnGenerate.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnGenerate.Name = "btnGenerate";
            this.btnGenerate.Size = new System.Drawing.Size(180, 58);
            this.btnGenerate.TabIndex = 2;
            this.btnGenerate.Text = "Generate";
            this.btnGenerate.UseVisualStyleBackColor = true;
            this.btnGenerate.Click += new System.EventHandler(this.btnGenerate_Click);
            // 
            // txtColumns
            // 
            this.txtColumns.Location = new System.Drawing.Point(400, 29);
            this.txtColumns.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtColumns.Name = "txtColumns";
            this.txtColumns.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.txtColumns.Size = new System.Drawing.Size(157, 31);
            this.txtColumns.TabIndex = 1;
            // 
            // txtRows
            // 
            this.txtRows.Location = new System.Drawing.Point(93, 29);
            this.txtRows.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtRows.Name = "txtRows";
            this.txtRows.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.txtRows.Size = new System.Drawing.Size(157, 31);
            this.txtRows.TabIndex = 0;
            // 
            // pnlToolBox
            // 
            this.pnlToolBox.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pnlToolBox.Controls.Add(this.rdbNone);
            this.pnlToolBox.Controls.Add(this.rdbGreenBox);
            this.pnlToolBox.Controls.Add(this.rdbRedBox);
            this.pnlToolBox.Controls.Add(this.rdbGreenDoor);
            this.pnlToolBox.Controls.Add(this.rdbWall);
            this.pnlToolBox.Controls.Add(this.rdbRedDoor);
            this.pnlToolBox.Controls.Add(this.lblToolbox);
            this.pnlToolBox.Location = new System.Drawing.Point(0, 149);
            this.pnlToolBox.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.pnlToolBox.Name = "pnlToolBox";
            this.pnlToolBox.Size = new System.Drawing.Size(281, 1160);
            this.pnlToolBox.TabIndex = 2;
            // 
            // rdbNone
            // 
            this.rdbNone.Appearance = System.Windows.Forms.Appearance.Button;
            this.rdbNone.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.rdbNone.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.rdbNone.Location = new System.Drawing.Point(21, 78);
            this.rdbNone.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.rdbNone.Name = "rdbNone";
            this.rdbNone.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.rdbNone.Size = new System.Drawing.Size(229, 92);
            this.rdbNone.TabIndex = 8;
            this.rdbNone.TabStop = true;
            this.rdbNone.Text = "None";
            this.rdbNone.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.rdbNone.UseVisualStyleBackColor = true;
            this.rdbNone.Click += new System.EventHandler(this.ToolBar_CheckChanged);
            // 
            // rdbGreenBox
            // 
            this.rdbGreenBox.Appearance = System.Windows.Forms.Appearance.Button;
            this.rdbGreenBox.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.rdbGreenBox.Location = new System.Drawing.Point(21, 578);
            this.rdbGreenBox.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.rdbGreenBox.Name = "rdbGreenBox";
            this.rdbGreenBox.Size = new System.Drawing.Size(229, 92);
            this.rdbGreenBox.TabIndex = 11;
            this.rdbGreenBox.TabStop = true;
            this.rdbGreenBox.Text = "Green Box";
            this.rdbGreenBox.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.rdbGreenBox.UseVisualStyleBackColor = true;
            this.rdbGreenBox.Click += new System.EventHandler(this.ToolBar_CheckChanged);
            // 
            // rdbRedBox
            // 
            this.rdbRedBox.Appearance = System.Windows.Forms.Appearance.Button;
            this.rdbRedBox.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.rdbRedBox.Location = new System.Drawing.Point(21, 478);
            this.rdbRedBox.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.rdbRedBox.Name = "rdbRedBox";
            this.rdbRedBox.Size = new System.Drawing.Size(229, 92);
            this.rdbRedBox.TabIndex = 10;
            this.rdbRedBox.TabStop = true;
            this.rdbRedBox.Text = "Red Box";
            this.rdbRedBox.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.rdbRedBox.UseVisualStyleBackColor = true;
            this.rdbRedBox.Click += new System.EventHandler(this.ToolBar_CheckChanged);
            // 
            // rdbGreenDoor
            // 
            this.rdbGreenDoor.Appearance = System.Windows.Forms.Appearance.Button;
            this.rdbGreenDoor.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.rdbGreenDoor.Location = new System.Drawing.Point(21, 378);
            this.rdbGreenDoor.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.rdbGreenDoor.Name = "rdbGreenDoor";
            this.rdbGreenDoor.Size = new System.Drawing.Size(229, 92);
            this.rdbGreenDoor.TabIndex = 9;
            this.rdbGreenDoor.TabStop = true;
            this.rdbGreenDoor.Text = "Green Door";
            this.rdbGreenDoor.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.rdbGreenDoor.UseVisualStyleBackColor = true;
            this.rdbGreenDoor.Click += new System.EventHandler(this.ToolBar_CheckChanged);
            // 
            // rdbWall
            // 
            this.rdbWall.Appearance = System.Windows.Forms.Appearance.Button;
            this.rdbWall.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.rdbWall.Location = new System.Drawing.Point(21, 178);
            this.rdbWall.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.rdbWall.Name = "rdbWall";
            this.rdbWall.Size = new System.Drawing.Size(229, 92);
            this.rdbWall.TabIndex = 7;
            this.rdbWall.TabStop = true;
            this.rdbWall.Text = "Wall";
            this.rdbWall.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.rdbWall.UseVisualStyleBackColor = true;
            this.rdbWall.Click += new System.EventHandler(this.ToolBar_CheckChanged);
            // 
            // rdbRedDoor
            // 
            this.rdbRedDoor.Appearance = System.Windows.Forms.Appearance.Button;
            this.rdbRedDoor.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.rdbRedDoor.Location = new System.Drawing.Point(21, 278);
            this.rdbRedDoor.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.rdbRedDoor.Name = "rdbRedDoor";
            this.rdbRedDoor.Size = new System.Drawing.Size(229, 92);
            this.rdbRedDoor.TabIndex = 8;
            this.rdbRedDoor.TabStop = true;
            this.rdbRedDoor.Text = "Red Door";
            this.rdbRedDoor.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.rdbRedDoor.UseVisualStyleBackColor = true;
            this.rdbRedDoor.Click += new System.EventHandler(this.ToolBar_CheckChanged);
            // 
            // lblToolbox
            // 
            this.lblToolbox.AutoSize = true;
            this.lblToolbox.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblToolbox.Location = new System.Drawing.Point(47, 20);
            this.lblToolbox.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblToolbox.Name = "lblToolbox";
            this.lblToolbox.Size = new System.Drawing.Size(162, 44);
            this.lblToolbox.TabIndex = 0;
            this.lblToolbox.Text = "Toolbox";
            // 
            // DesignForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.ClientSize = new System.Drawing.Size(1667, 1111);
            this.Controls.Add(this.pnlToolBox);
            this.Controls.Add(this.pnlRowsAndColumns);
            this.Controls.Add(this.menuStrip);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MainMenuStrip = this.menuStrip;
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "DesignForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Design Form";
            this.Load += new System.EventHandler(this.DesignForm_Load);
            this.menuStrip.ResumeLayout(false);
            this.menuStrip.PerformLayout();
            this.pnlRowsAndColumns.ResumeLayout(false);
            this.pnlRowsAndColumns.PerformLayout();
            this.pnlToolBox.ResumeLayout(false);
            this.pnlToolBox.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem saveToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
        private System.Windows.Forms.Panel pnlRowsAndColumns;
        private System.Windows.Forms.Label lblColumns;
        private System.Windows.Forms.Label lblRows;
        private System.Windows.Forms.Button btnGenerate;
        private System.Windows.Forms.TextBox txtColumns;
        private System.Windows.Forms.TextBox txtRows;
        private System.Windows.Forms.Panel pnlToolBox;
        private System.Windows.Forms.Label lblToolbox;
        private System.Windows.Forms.RadioButton rdbNone;
        private System.Windows.Forms.RadioButton rdbGreenBox;
        private System.Windows.Forms.RadioButton rdbRedBox;
        private System.Windows.Forms.RadioButton rdbGreenDoor;
        private System.Windows.Forms.RadioButton rdbWall;
        private System.Windows.Forms.RadioButton rdbRedDoor;
    }
}