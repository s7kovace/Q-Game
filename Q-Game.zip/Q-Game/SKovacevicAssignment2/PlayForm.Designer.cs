﻿namespace Q_Game
{
    partial class PlayForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip = new System.Windows.Forms.MenuStrip();
            this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.loadGameToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.closeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pnlPlayGame = new System.Windows.Forms.Panel();
            this.txtMoveCounter = new System.Windows.Forms.TextBox();
            this.txtBoxCounter = new System.Windows.Forms.TextBox();
            this.lblNumberOfMoves = new System.Windows.Forms.Label();
            this.lblNumberOfRemainingBoxes = new System.Windows.Forms.Label();
            this.btnUp = new System.Windows.Forms.Button();
            this.btnLeft = new System.Windows.Forms.Button();
            this.btnDown = new System.Windows.Forms.Button();
            this.btnRight = new System.Windows.Forms.Button();
            this.menuStrip.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip
            // 
            this.menuStrip.GripMargin = new System.Windows.Forms.Padding(2, 2, 0, 2);
            this.menuStrip.ImageScalingSize = new System.Drawing.Size(24, 24);
            this.menuStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem});
            this.menuStrip.Location = new System.Drawing.Point(0, 0);
            this.menuStrip.Name = "menuStrip";
            this.menuStrip.Padding = new System.Windows.Forms.Padding(6, 2, 0, 2);
            this.menuStrip.Size = new System.Drawing.Size(1250, 33);
            this.menuStrip.TabIndex = 0;
            this.menuStrip.Text = "menuStrip1";
            // 
            // fileToolStripMenuItem
            // 
            this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.loadGameToolStripMenuItem,
            this.closeToolStripMenuItem});
            this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            this.fileToolStripMenuItem.Size = new System.Drawing.Size(54, 29);
            this.fileToolStripMenuItem.Text = "File";
            // 
            // loadGameToolStripMenuItem
            // 
            this.loadGameToolStripMenuItem.Name = "loadGameToolStripMenuItem";
            this.loadGameToolStripMenuItem.Size = new System.Drawing.Size(204, 34);
            this.loadGameToolStripMenuItem.Text = "Load Game";
            this.loadGameToolStripMenuItem.Click += new System.EventHandler(this.loadGameToolStripMenuItem_Click);
            // 
            // closeToolStripMenuItem
            // 
            this.closeToolStripMenuItem.Name = "closeToolStripMenuItem";
            this.closeToolStripMenuItem.Size = new System.Drawing.Size(204, 34);
            this.closeToolStripMenuItem.Text = "Close";
            this.closeToolStripMenuItem.Click += new System.EventHandler(this.closeToolStripMenuItem_Click);
            // 
            // pnlPlayGame
            // 
            this.pnlPlayGame.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pnlPlayGame.Location = new System.Drawing.Point(26, 49);
            this.pnlPlayGame.Name = "pnlPlayGame";
            this.pnlPlayGame.Size = new System.Drawing.Size(925, 724);
            this.pnlPlayGame.TabIndex = 2;
            // 
            // txtMoveCounter
            // 
            this.txtMoveCounter.Enabled = false;
            this.txtMoveCounter.Location = new System.Drawing.Point(990, 106);
            this.txtMoveCounter.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txtMoveCounter.Name = "txtMoveCounter";
            this.txtMoveCounter.ReadOnly = true;
            this.txtMoveCounter.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.txtMoveCounter.Size = new System.Drawing.Size(220, 26);
            this.txtMoveCounter.TabIndex = 3;
            this.txtMoveCounter.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtBoxCounter
            // 
            this.txtBoxCounter.Enabled = false;
            this.txtBoxCounter.Location = new System.Drawing.Point(990, 192);
            this.txtBoxCounter.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txtBoxCounter.Name = "txtBoxCounter";
            this.txtBoxCounter.ReadOnly = true;
            this.txtBoxCounter.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.txtBoxCounter.Size = new System.Drawing.Size(220, 26);
            this.txtBoxCounter.TabIndex = 4;
            this.txtBoxCounter.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // lblNumberOfMoves
            // 
            this.lblNumberOfMoves.AutoSize = true;
            this.lblNumberOfMoves.Location = new System.Drawing.Point(986, 82);
            this.lblNumberOfMoves.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblNumberOfMoves.Name = "lblNumberOfMoves";
            this.lblNumberOfMoves.Size = new System.Drawing.Size(137, 20);
            this.lblNumberOfMoves.TabIndex = 5;
            this.lblNumberOfMoves.Text = "Number of Moves:";
            // 
            // lblNumberOfRemainingBoxes
            // 
            this.lblNumberOfRemainingBoxes.AutoSize = true;
            this.lblNumberOfRemainingBoxes.Location = new System.Drawing.Point(986, 168);
            this.lblNumberOfRemainingBoxes.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblNumberOfRemainingBoxes.Name = "lblNumberOfRemainingBoxes";
            this.lblNumberOfRemainingBoxes.Size = new System.Drawing.Size(211, 20);
            this.lblNumberOfRemainingBoxes.TabIndex = 6;
            this.lblNumberOfRemainingBoxes.Text = "Number of Remaining Boxes";
            // 
            // btnUp
            // 
            this.btnUp.Location = new System.Drawing.Point(1065, 595);
            this.btnUp.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnUp.Name = "btnUp";
            this.btnUp.Size = new System.Drawing.Size(75, 77);
            this.btnUp.TabIndex = 7;
            this.btnUp.Text = "Up";
            this.btnUp.UseVisualStyleBackColor = true;
            this.btnUp.Click += new System.EventHandler(this.btnUp_Click);
            // 
            // btnLeft
            // 
            this.btnLeft.Location = new System.Drawing.Point(981, 682);
            this.btnLeft.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnLeft.Name = "btnLeft";
            this.btnLeft.Size = new System.Drawing.Size(75, 77);
            this.btnLeft.TabIndex = 8;
            this.btnLeft.Text = "Left";
            this.btnLeft.UseVisualStyleBackColor = true;
            this.btnLeft.Click += new System.EventHandler(this.btnLeft_Click);
            // 
            // btnDown
            // 
            this.btnDown.Location = new System.Drawing.Point(1065, 682);
            this.btnDown.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnDown.Name = "btnDown";
            this.btnDown.Size = new System.Drawing.Size(75, 77);
            this.btnDown.TabIndex = 9;
            this.btnDown.Text = "Down";
            this.btnDown.UseVisualStyleBackColor = true;
            this.btnDown.Click += new System.EventHandler(this.btnDown_Click);
            // 
            // btnRight
            // 
            this.btnRight.Location = new System.Drawing.Point(1149, 682);
            this.btnRight.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnRight.Name = "btnRight";
            this.btnRight.Size = new System.Drawing.Size(75, 77);
            this.btnRight.TabIndex = 10;
            this.btnRight.Text = "Right";
            this.btnRight.UseVisualStyleBackColor = true;
            this.btnRight.Click += new System.EventHandler(this.btnRight_Click);
            // 
            // PlayForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.ClientSize = new System.Drawing.Size(1250, 792);
            this.Controls.Add(this.btnRight);
            this.Controls.Add(this.btnDown);
            this.Controls.Add(this.btnLeft);
            this.Controls.Add(this.btnUp);
            this.Controls.Add(this.lblNumberOfRemainingBoxes);
            this.Controls.Add(this.lblNumberOfMoves);
            this.Controls.Add(this.txtBoxCounter);
            this.Controls.Add(this.txtMoveCounter);
            this.Controls.Add(this.pnlPlayGame);
            this.Controls.Add(this.menuStrip);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MainMenuStrip = this.menuStrip;
            this.Name = "PlayForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "PlayForm";
            this.Load += new System.EventHandler(this.PlayForm_Load);
            this.menuStrip.ResumeLayout(false);
            this.menuStrip.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem loadGameToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem closeToolStripMenuItem;
        private System.Windows.Forms.Panel pnlPlayGame;
        private System.Windows.Forms.TextBox txtMoveCounter;
        private System.Windows.Forms.TextBox txtBoxCounter;
        private System.Windows.Forms.Label lblNumberOfMoves;
        private System.Windows.Forms.Label lblNumberOfRemainingBoxes;
        private System.Windows.Forms.Button btnUp;
        private System.Windows.Forms.Button btnLeft;
        private System.Windows.Forms.Button btnDown;
        private System.Windows.Forms.Button btnRight;
    }
}