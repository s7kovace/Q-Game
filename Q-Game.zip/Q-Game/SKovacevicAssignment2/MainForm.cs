﻿/* $ MainForm.cs
 * Assignment 2
 * Revision History
 * 
 * Stefan Kovacevic, 2020.11.08: Created, Revised, Tested
 * Student ID: 7202039
 
 */

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

/// <summary>
/// This Form has an option to design the level or play the game.
/// </summary>
namespace Q_Game
{
    /// <summary>
    /// Main Form of the MiniGame.
    /// </summary>
    public partial class MainForm : Form
    {
        /// <summary>
        /// Constructor of Main Form
        /// </summary>
        public MainForm()
        {
            InitializeComponent();
        }

        private void btnDesign_Click(object sender, EventArgs e)
        {
            DesignForm designForm = new DesignForm();

            designForm.ShowDialog(this);
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnPlay_Click(object sender, EventArgs e)
        {
            PlayForm playForm = new PlayForm();
            playForm.ShowDialog(this);
        }
    }
}
