﻿/* $ DesignForm.cs
 * Assignment 2
 * Revision History
 * 
 * Stefan Kovacevic, 2020.11.08: Created, Revised, Tested
 * Student ID: 7202039
 
 */
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

/// <summary>
/// Create and design a level for the game, then save afterwards.
/// </summary>
namespace Q_Game
{
    /// <summary>
    /// Design levels for Mini game
    /// </summary>
    public partial class DesignForm : Form
    {
        private Image redDoor = Q_Game.Properties.Resources.redDoor;
        private Image greenDoor = Q_Game.Properties.Resources.greenDoor;
        private Image greenBox = Q_Game.Properties.Resources.greenBox;
        private Image redBox = Q_Game.Properties.Resources.redBox;
        private Image wall = Q_Game.Properties.Resources.brickWall;
        private Image noImage = Q_Game.Properties.Resources.silverSquare;     
        private Image globalImage = null;
        private int globalInt = 0;
        private ImageList imageList = new ImageList();
        int rows;
        int columns;


        /// <summary>
        /// The constructor of the form
        /// </summary>
        public DesignForm()
        {
            InitializeComponent();
            
        }

        /// <summary>
        /// Puts images to an image list and assigns the image to the corresponding radiobutton
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void DesignForm_Load(object sender, EventArgs e)
        {
            imageList.Images.Add(redDoor);
            imageList.Images.Add(greenDoor);
            imageList.Images.Add(greenBox);
            imageList.Images.Add(redBox);
            imageList.Images.Add(wall);
            imageList.Images.Add(noImage);

            imageList.ImageSize = new Size(50, 50);
            rdbRedDoor.Image = imageList.Images[0];
            rdbGreenDoor.Image = imageList.Images[1];
            rdbGreenBox.Image = imageList.Images[2];
            rdbRedBox.Image = imageList.Images[3];
            rdbWall.Image = imageList.Images[4];
            rdbNone.Image = imageList.Images[5];


        }
         
        /// <summary>
        /// Generates a grid of pictureboxes if the inputs are valid, otherwise displays an error message
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnGenerate_Click(object sender, EventArgs e)
        {
            //*******ASK PROFESSOR WHY THIS IS BUGGED DURING DEMO!!!***********************************************
            //foreach (PictureBox p in this.Controls.OfType<PictureBox>())
            //{
            //    this.Controls.Remove(p);
            //}

            int xAxisOfPictureBox = 200;
            int yAxisOfPictureBox = 100;

            if (int.TryParse(txtRows.Text, out rows) && int.TryParse(txtColumns.Text,out columns))
            {

                int i = 0, j = 0;

                while (i < rows)
                {
                    while (j < columns)
                    {
                        PictureBox pictureBox = new PictureBox();
                        pictureBox.Size = new Size(60, 60);
                        pictureBox.BorderStyle = BorderStyle.Fixed3D;
                        pictureBox.Location = new Point(xAxisOfPictureBox, yAxisOfPictureBox);
                        pictureBox.SizeMode = PictureBoxSizeMode.Zoom;
                        pictureBox.Visible = true;
                        pictureBox.Tag = 0;
                        pictureBox.Click += new EventHandler(DynamicPictureBox_Click);
                        xAxisOfPictureBox += 60;
                        j++;
                        this.Controls.Add(pictureBox);
                    }
                    xAxisOfPictureBox = 200;
                    yAxisOfPictureBox += 60;
                    j = 0;
                    i++;
                }
                pnlRowsAndColumns.Enabled = false;
            }
            else
            {
                MessageBox.Show("Please provide valid data for rows and colums(Both must be integers)","QGame",MessageBoxButtons.OK,MessageBoxIcon.Error);
            }

        }
        /// <summary>
        /// Red Door = 1
        /// Red Box = 2
        /// Green Box = 3
        /// Green Door = 4
        /// Wall = 5
        /// </summary>
        private void ToolBar_CheckChanged(object sender, EventArgs e)
        {
            RadioButton radioButton = (RadioButton)sender;
            if (rdbNone.Checked == true)
            {
                globalImage = null;
                globalInt = 0;
            }
            else if(rdbRedDoor.Checked == true)
            {
                globalImage = redDoor;
                globalInt = 1;
            }
            else if (rdbRedBox.Checked == true)
            {
                globalImage = redBox;
                globalInt = 2;
            }
            else if (rdbGreenBox.Checked == true)
            {
                globalImage = greenBox;
                globalInt = 3;
            }
            else if (rdbGreenDoor.Checked == true)
            {
                globalImage = greenDoor;
                globalInt = 4;
            }
            else if (rdbWall.Checked == true)
            {
                globalImage = wall;
                globalInt = 5;
            }
        }

        /// <summary>
        /// assigns tool box picture and number to dynamic picturebox
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void DynamicPictureBox_Click(object sender, EventArgs e)
        {
            PictureBox selectedPictureBox = (PictureBox)sender;

            selectedPictureBox.Image = globalImage;
            selectedPictureBox.Tag = globalInt;


        }


        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }


        private void saveToolStripMenuItem_Click(object sender, EventArgs e)
        {
            int redDoorCount=0;
            int greenDoorCount=0;
            int redBoxCount=0;
            int greenBoxCount=0;
            int wallCount=0;
            SaveFileDialog saveFileDialog = new SaveFileDialog();
            saveFileDialog.Filter = "QGAME File(*.qgame)|*.qgame";
            saveFileDialog.FileName = "sampleQgameFile";
            if (saveFileDialog.ShowDialog() == DialogResult.OK)
            {
                string filePath = saveFileDialog.FileName;
                int rowCount = 0, columnCount = 0;

                using (StreamWriter sw = new StreamWriter(filePath))
                {
                    sw.WriteLine(rows);
                    sw.WriteLine(columns);

                    foreach  (PictureBox p in this.Controls.OfType<PictureBox>())
                    {
                        if (columnCount == columns)
                        {
                            columnCount = 0;
                            rowCount = rowCount + 1;
                        }

                            sw.WriteLine(rowCount);
                            sw.WriteLine(columnCount);
                            sw.WriteLine(p.Tag);
                            columnCount++;

                        if (p.Tag.ToString() == "1")
                        {
                            redDoorCount += 1;
                        }
                        else if (p.Tag.ToString() == "2")
                        {
                            redBoxCount += 1;
                        }

                        else if (p.Tag.ToString() == "3")
                        {
                            greenBoxCount += 1;
                        }
                        else if (p.Tag.ToString() == "4")
                        {
                            greenDoorCount += 1;
                        }
                        else if (p.Tag.ToString() == "5")
                        {
                            wallCount += 1;
                        }

                    }



                }
                StringBuilder sb = new StringBuilder();
                sb.Append($"File Saved Successfully: \n");

                if (redDoorCount != 0)
                {
                    sb.Append($"Total Number of Red Doors: {redDoorCount}\n");
                }
                if(redBoxCount != 0)
                {
                    sb.Append($"Total Number of Red Boxes: {redBoxCount}\n");
                }
                if(greenBoxCount != 0)
                {
                    sb.Append($"Total Number of Green Boxes: {greenBoxCount}\n");

                }
                if(greenDoorCount != 0)
                {
                    sb.Append($"Total Number of Green Doors: {greenDoorCount}\n");
                }
                if (wallCount != 0)
                {
                    sb.Append($"Total Number of Walls: {wallCount}\n");
                }

                MessageBox.Show(sb.ToString(), "QGame", MessageBoxButtons.OK, MessageBoxIcon.Information);

            }
        }
    }
}
